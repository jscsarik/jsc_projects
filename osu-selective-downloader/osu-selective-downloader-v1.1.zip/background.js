chrome.runtime.onInstalled.addListener(()=>{console.log("osu! Selective Downloader extension installed.")});
